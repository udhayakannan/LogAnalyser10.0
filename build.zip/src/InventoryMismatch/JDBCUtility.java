package InventoryMismatch;


import java.sql.*;
import java.util.*;


public class JDBCUtility{
	
	
	private String url,userID, pwd,header,fileName;
	private Connection con;

	
	public JDBCUtility(String url, String userID, String pwd) throws Exception{
		
		this.url = url;
		this.userID = userID;
		this.pwd = pwd;
		setConnection();
            
	}
	
	
	public void setHeader(String header){
		
		this.header = header;
	}
	
	public void setFileName(String fileName){
		
		this.fileName = fileName;
	}
	
	
	
	
	
	public ArrayList collectData(String sql) throws Exception{
		
		ArrayList<String> al = new ArrayList();
		Statement smt = con.createStatement();
		
		ResultSet rs = smt.executeQuery(sql);
		ResultSetMetaData rsmd=rs.getMetaData();
		int noOfColumns = rsmd.getColumnCount();
		while (rs.next()){
			
			StringBuffer row = new StringBuffer();
			
			for (int i=1; i< noOfColumns;i++){
				
				row.append(rs.getString(i).trim());row.append(",");	
				
			}
			row.append (rs.getString(noOfColumns).trim());
			al.add(row.toString());
			
		}
		rs.close();
		smt.close();
		
		return al;
		
	}
	
	
	public void getData(String sql) throws Exception{
		CreateCSV csv = new CreateCSV(fileName,false);  
        csv.openFile();
		
		if(header!=null)
		csv.writeFile(header);
            
            
		Statement smt = con.createStatement();
		
		ResultSet rs = smt.executeQuery(sql);
		ResultSetMetaData rsmd=rs.getMetaData();
		int noOfColumns = rsmd.getColumnCount();
		
		while (rs.next()){
		
			StringBuffer row = new StringBuffer();
			
			for (int i=1; i< noOfColumns;i++){
				
				row.append(rs.getString(i));row.append(",");	
				
			}
			
			row.append (rs.getString(noOfColumns));
			
			csv.writeFile(row.toString());
            
			
			
		}//while
		rs.close();
		smt.close();
		csv.closeFile();
	
	}
	
	private void setConnection() throws Exception{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 con =DriverManager.getConnection(url,userID, pwd);
		 
		
		
	}
	
}