package InventoryMismatch;

import com.sun.org.apache.xml.internal.security.exceptions.Base64DecodingException;
import com.sun.org.apache.xml.internal.security.utils.Base64;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Inventorycheck {
 byte[] pass ;String pass1 =null;
    public void GIVInvenory(String GIVDBname,String User,String Password) throws Exception {

        FileReader fr = null;
        BufferedReader br = null;
        fr = new FileReader("Store.txt");
        br = new BufferedReader(fr);
        String fileName = "GIVInventory.txt";
        CreateCSV csv = new CreateCSV(fileName, false);
        String data2Write = null;
        String Itemid = null;

        SimpleDateFormat date = new SimpleDateFormat("yyyyMMdd");//dd/MM/yyyy
        Date now = new Date();
        String date1 = date.format(now);
        csv.openFile();
        data2Write = "ItemId" + "," + "qty";
        csv.writeFile(data2Write);
        byte[] pass = Base64.decode(Password);
        String pass1 = new String(pass);
        JDBCUtility jdbc1 = new JDBCUtility(GIVDBname, User,pass1 );

        while ((Itemid = br.readLine()) != null) {
            ArrayList<String> data = new ArrayList();


            String query = "Select b.item_id,a.onhand_available_quantity\r\n"
                    + "from GV_ADMIN.yfs_inventory_alerts a inner join  GV_ADMIN.YFS_INVENTORY_ITEM b\r\n"
                    + "on a.inventory_item_key = b.inventory_item_key\r\n"
                    + "where b.item_id = '" + Itemid + "' and a.ship_node = ' ' and  \r\n"
                    + "to_char(onhand_available_date, 'YYYYMMDD') >= '20171220'";







            data = jdbc1.collectData(query);



            /*String previousOrder ="";boolean firstSkip = true;
            String previousNodes ="";String previousQty ="";
            String itemID_lines ="";
            String Shipment_lines ="";*/

            System.out.println("GIV Data:" + data);
            for (String line : data) {

                String[] details = line.split(",");
                String ItemId = details[0];
                String qty = details[1];
                //	String count = details[2];


                System.out.print("ItemId =" + ItemId);
                data2Write = ItemId + "," + qty;
                csv.writeFile(data2Write);



            }
        }
        csv.closeFile();


    }

   
}
