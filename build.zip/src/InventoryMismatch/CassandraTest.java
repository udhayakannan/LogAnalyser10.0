package InventoryMismatch;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.datastax.driver.core.Row;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.xml.security.exceptions.Base64DecodingException;

public class CassandraTest {

    static CassandraDAO cassandra;

    public static void getValueFromCassandra(String clusterAddress, String userName, String passWord, String keySpace) throws InterruptedException, IOException, Base64DecodingException {
//    		String clusterAddress = "ocf-oicdb2-stressa-csdra-s-2.tst.kohls.com";
//    		String userName = "user00";
//    		String passWord = "S2luZ05ETm9ydGg=";
//    		String keySpace = "appdata00";
        String read = null;
        int value = 0;
       
        cassandra = new CassandraDAO(clusterAddress, userName, passWord, keySpace);
       
      
        FileReader fr = null;
        BufferedReader br = null;
        String data2Write = null;
        String fileName = "InventoryMismatch.txt";
        CreateCSV csv = new CreateCSV(fileName, false);
        csv.openFile();
        fr = new FileReader("GIVInventory.txt");
        br = new BufferedReader(fr);
        data2Write = "ItemId" + "," + "GIVInventory_Value" + "," + "C*Inventory_Value" + ","+"Inventory Mismatch count";

        csv.writeFile(data2Write);
        String Header = br.readLine();
        String[] details1 = Header.split(",");
        while ((read = br.readLine()) != null) {
            String[] details = read.split(",");
            String ItemId = details[0];
            String qty = details[1];
            int qty1 = Integer.parseInt(qty);
            System.out.println("Ship Item: " + ItemId);
            System.out.println("Ship Qty: " + ItemId);
            value = getValueFromCassandraQuery(ItemId);
            System.out.println("Ship ATP: " + value);
            int difference = qty1 - value;
            data2Write = ItemId + "," + qty + "," + value + "," + difference;
            csv.writeFile(data2Write);



        }




        csv.closeFile();

    }

    public static int getValueFromCassandraQuery(String itemID) throws InterruptedException {
         int value = 0;
        Row row = cassandra.executeQuery("select shipatp from oic_enterprise_atp where itemid = '" + itemID + "'").one();
        try{
             value = row.getInt("shipatp");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println("Ship ATP: " + value);
        return value;
    }
}
