package InventoryMismatch;


import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Cluster.Builder;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.Statement;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import org.apache.xml.security.exceptions.Base64DecodingException;
//import com.sun.org.apache.xml.internal.security.utils.Base64;





public class CassandraDAO {

	protected Session session;
	private String keyspace;
	public CassandraDAO(String clusterAddress, String username, String password, String keyspace) throws Base64DecodingException {
       Cluster cluster = Cluster.builder().addContactPoints(clusterAddress.split(","))
          .withCredentials(username, new String(Base64.decode(password))).build();
                session = cluster.connect(keyspace);
        System.out.println("Cassandra session was successfully established for\n Cluster: "+clusterAddress+"\n Username: "+username+"\n Keyspace: "+keyspace);
        this.keyspace = keyspace;
    }
	
	public ResultSet executeQuery(String query) {
        Statement statement = new SimpleStatement(query);
        statement.setFetchSize(500);
        return session.execute(statement);
    }
}
