package OIC_SmokeTest;

import java.io.IOException;
import java.util.ArrayList;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import java.text.SimpleDateFormat; 
import java.util.*;

public class Supply {

	/**
	 * Udhaya
	 */
	
	    
	    static int Quantity =10;
		 static int ShipNode=819;
		static int ItemID=73940395;
	  
	    
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			
	    // Variables used by more than one method
	    StringBuffer sb = new StringBuffer();
	    
	    StringBuffer sb1 = new StringBuffer();
	    String date = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
	 	sb1.append("<Items>");
	 	sb1.append("<Item AdjustmentType=\"ADJUSTMENT\" Availability=\"TRACK\" ItemID=\""+ItemID+"\"");
	 	sb1.append(" OrganizationCode=\"DEFAULT\" ProductClass=\"Good\" Quantity=\""+Quantity+"\"" );
	  	sb1.append(" ReasonCode=\"EFCADJ\" ReasonText=\"\" ShipNode=\""+ShipNode+"\" SupplyType=\"EF_ONHAND.ex\" UnitOfMeasure=\"EACH\" Reference_1=\"8290709\" Reference_2=\"\" Reference_3=\""+date+"\"");
	 	sb1.append(" Reference_4=\""+ShipNode+"_000001\">");
	 	sb1.append("</Item>");
	 	sb1.append("</Items>");
	 	
	 	 String msgBody1 = sb1.toString();

	 	System.out.print(msgBody1);
	    mqdetails mq = new mqdetails();
	  
	    mq.Supply(ShipNode);
	    mq.action(msgBody1);

      //   JDBCUtility jdbc1 = new JDBCUtility("jdbc:oracle:thin:@OR0145S.TST.KOHLS.COM:1521/OS0145_APP_OMSEC1N1.kohls.com","ofteam","ofteam");
     
        
        //2017-09-13T08:26:22
   	
   	
     ArrayList<String> data = new ArrayList();
   
 	 
 	
   
   
    
		

	}

}
