package OIC_SmokeTest;

import java.io.IOException;
import java.util.ArrayList;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import java.text.SimpleDateFormat; 
import java.util.*;

public class CreateOrder {

	/**
	 * Udhaya
	 */
	
	      
	    
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			
	    // Variables used by more than one method
	    StringBuffer sb = new StringBuffer();
	    
	    StringBuffer sb1 = new StringBuffer();
	    String date = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
	 	
	 
	 	
	 	 String msgBody1 = sb1.toString();

	 	sb1.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?><Order CustomerEMailID=\"IBbY2MdjKZV5xfQR0Obh5vI/c07vyr8fGYgU1Hneo2DlCujd5Uq8wWeXd5Ptg2Jn+kQ=\" DocumentType=\"0001\" EnteredBy=\"843068600\" EnterpriseCode=\"KOHLS.COM\" OrderDate=\"2017-03-01T05:31:53-05:00\" OrderNo=\"20171007020000004\" >");
	 	sb1.append("<HeaderCharges>");
	 	sb1.append("<HeaderCharge ChargeAmount=\"1.95\" ChargeCategory=\"Shipping\" ChargeName=\"Shipping\" Reference=\"3\" /> ");
	 	sb1.append("</HeaderCharges>");
	 	sb1.append("<HeaderTaxes>");
	 	sb1.append("<HeaderTax ChargeCategory=\"ShippingTax\" ChargeName=\"ShippingTax\" Tax=\"0.00\" TaxName=\"total tax\" TaxPercentage=\"0.000\" TaxableFlag=\"Y\" />");
	 	sb1.append("</HeaderTaxes><Extn ExtnVersion=\"1.2\" />");
	 	sb1.append("<OrderLines>");
	 	sb1.append("<OrderLine CarrierServiceCode=\"Standard Ground\" GiftFlag=\"N\" GiftWrap=\"N\" LineType=\"\" OrderedQty=\"1\" PrimeLineNo=\"1\" ProductLine=\"\">");
	 	sb1.append("<Extn ExtnCurrentItemStatus=\"20\" ExtnDSVCost=\"\" ExtnIsHazardous=\"N\" ExtnShipAlone=\"\" ExtnTaxableAmount=\"29.99\" ExtnWrapTogetherGroupCode=\"\" /> ");
	 	sb1.append("<Item ItemID=\"73940395\" ItemShortDesc=\"60000001 vQIgdgwJn\" ProductClass=\"Good\" UnitOfMeasure=\"EACH\" /> ");
	 	sb1.append("<LinePriceInfo IsPriceLocked=\"Y\" ListPrice=\"1.22\" RetailPrice=\"1.22\" TaxableFlag=\"Y\" UnitPrice=\"1.22\" />");
	 	sb1.append("<LineTaxes>");
	 	sb1.append("<LineTax ChargeCategory=\"Tax\" ChargeName=\"Tax\" Reference1=\"\" Reference2=\"\" Reference3=\"\" Tax=\"2.36\" TaxName=\"SALES_TAX\" TaxPercentage=\"0.0475\" TaxableFlag=\"Y\" /> ");
	 	sb1.append("</LineTaxes>");
	 	sb1.append("<PersonInfoShipTo AddressLine1=\"555 LuNGYFjWvvEUAeO Hwy\" City=\"Bakersfield\" Country=\"US\" DayPhone=\"1804047072\" EmailID=\"IBbY2MdjKZV5xfQR0Obh5vI/c07vyr8fGYgU1Hneo2DlCujd5Uq8wWeXd5Ptg2Jn+kQ=\" FirstName=\"IBZ1D/M7mLBNgIyUOQCIJyS4\" LastName=\"IBZv9Wzbvxko52eNpAhR2HCL\" State=\"CA\" ZipCode=\"93312\">");
	 	sb1.append("<Extn ExtnIsMilitary=\"N\" ExtnIsPOBox=\"N\" /> ");
	 	sb1.append("</PersonInfoShipTo>");
	 	sb1.append("</OrderLine>");
	 	sb1.append("</OrderLines>");
	 	sb1.append("<PersonInfoBillTo AddressLine1=\"555 LuNGYFjWvvEUAeO Hwy\" City=\"Bakersfield\" Country=\"US\" DayPhone=\"1804047072\" FirstName=\"IBZ1D/M7mLBNgIyUOQCIJyS4\" LastName=\"IBZv9Wzbvxko52eNpAhR2HCL\" State=\"CA\" ZipCode=\"IBbpn9KVJCV3Qc8SsKIReRFH\" />");
	 	sb1.append("<PaymentMethods>");
	 	sb1.append("<PaymentMethod CreditCardExpDate=\"2016-10-05T12:02:53-05:00\" CreditCardNo=\"5751547467221286\" CreditCardType=\"MSTR_CARD\" DisplayCreditCardNo=\"1286\" DisplayPaymentReference1=\"0002\" MaxChargeLimit=\"48.73\" PaymentReference1=\"trace?10512.nt63a.fip 212662 005440\" PaymentReference2=\"perf test\" PaymentReference3=\"00\" PaymentType=\"Credit Card\" SvcNo=\"\" UnlimitedCharges=\"N\">");
	 	sb1.append("<PaymentDetailsList>");
	 	sb1.append("<PaymentDetails AuthAmount=\"10048.73\" AuthAvs=\"M0\" AuthCode=\"222222\" AuthReturnCode=\"AJB_SAJBOK\" AuthReturnFlag=\"AJB_SAJBOK\" AuthReturnMessage=\"AJB_SAJBOK\" AuthTime=\"2015-10-05T12:02:53-05:00\" AuthorizationExpirationDate=\"2016-10-05T12:02:53-05:00\" AuthorizationID=\"XY2222\" CVVAuthCode=\"\" ChargeType=\"AUTHORIZATION\" HoldAgainstBook=\"Y\" PaymentType=\"Credit Card\" ProcessedAmount=\"10048.73\" Reference1=\"120912AB34CDE\" Reference2=\"\" RequestAmount=\"10048.73\" RequestId=\"\" />");
	 	sb1.append("</PaymentDetailsList>");
	 	sb1.append("</PaymentMethod>");
	 	sb1.append("</PaymentMethods>");
	 	sb1.append("<Extn ExtnKCECouponAmount=\"50.0\" ExtnKCECouponBalance=\"10.0\" ExtnKCECouponEventID=\"16080\"/>");
	 	sb1.append("</Order>");

	 	 
	 	System.out.print(msgBody1);
	 	mqdetails oms = new mqdetails();
	  
	   oms.Createorder();
	    oms.omsaction(msgBody1);

      //   JDBCUtility jdbc1 = new JDBCUtility("jdbc:oracle:thin:@OR0145S.TST.KOHLS.COM:1521/OS0145_APP_OMSEC1N1.kohls.com","ofteam","ofteam");
     
        
        //2017-09-13T08:26:22
   	
   	
   //  ArrayList<String> data = new ArrayList();
   
 	 
 	
   
   
    
		

	}

}
