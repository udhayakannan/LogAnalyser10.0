package OIC_SmokeTest;

import java.io.IOException;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;


public class mqdetails {
	
	  String queueMgr,QueueName;
	  public void Createorder() {
			// TODO Auto-generated method stub
			  
			   String msgBody = null;
			   String filename = null;
		}

		public void omsaction(String message) throws MQException, IOException {
			QueueName = "OF.INB.CRT_ORDER.Q";
			 MQQueueManager MQQueueManager = null;
			    MQQueue putQueue = null;
			    MQPutMessageOptions post = new MQPutMessageOptions();
			    MQMessage request= new MQMessage();
			    MQMessage response = new MQMessage();
			 String queueMgrName = "MQXL22AS";
			 MQEnvironment.hostname = "nl001173.tst.kohls.com";
		     MQEnvironment.port = 50500;
		     MQEnvironment.channel = "OF.DEF.SVRCONN";
		     MQEnvironment.userID = "nzomse";
			MQQueueManager = new MQQueueManager(queueMgr);
	    // Access the put/get queues
	    putQueue = MQQueueManager.accessQueue(QueueName, MQC.MQOO_BIND_NOT_FIXED | MQC.MQOO_OUTPUT);
	    
	    request.format = MQC.MQFMT_STRING;
	    request.writeString(message); 
	    putQueue.put(request, post);
	    
	    // Clear the message objects on each iteration.
	    request.clearMessage();
	    response.clearMessage();
		}

	public void action(String message) throws MQException, IOException {
		
		 MQQueueManager MQQueueManager = null;
		    MQQueue putQueue = null;
		    MQPutMessageOptions post = new MQPutMessageOptions();
		    MQMessage request= new MQMessage();
		    MQMessage response = new MQMessage();
		    queueMgr = "MQXL24AS";
		 MQEnvironment.hostname = "nl000636.tst.kohls.com";
	     MQEnvironment.port = 50500;
	     MQEnvironment.channel = "GIV.DEF.SVRCONN";
	     MQEnvironment.userID = "nzgiv";
		MQQueueManager = new MQQueueManager(queueMgr);
     // Access the put/get queues
     putQueue = MQQueueManager.accessQueue(QueueName, MQC.MQOO_BIND_NOT_FIXED | MQC.MQOO_OUTPUT);
     
     request.format = MQC.MQFMT_STRING;
     request.writeString(message); 
     putQueue.put(request, post);
     
     // Clear the message objects on each iteration.
     request.clearMessage();
     response.clearMessage();
	}
	

	
	public void Supply(int shipNode) {
		// TODO Auto-generated method stub

		   QueueName = "GV.IB.WS.ADJ.EFC_"+shipNode+".Q";
		   String msgBody = null;
		   String filename = null;
	}
	
}
